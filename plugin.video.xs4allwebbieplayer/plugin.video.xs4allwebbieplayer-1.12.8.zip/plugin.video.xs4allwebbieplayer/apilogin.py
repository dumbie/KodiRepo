import json
import random
import re
from datetime import datetime, timedelta
from threading import Thread
import xbmc
import xbmcgui
import alarm
import classes
import dialog
import download
import func
import hybrid
import path
import television
import var
import zap

def ApiGenerateDeviceId():
    if var.addon.getSetting('LoginDeviceId120') == '':
        DeviceId = ''
        random.seed(datetime.utcnow())
        for _ in range(64):
            DeviceId += str(random.randint(0,9))

        #Update the settings
        var.addon.setSetting('LoginDeviceId120', DeviceId)

def thread_login_auto():
    while var.thread_login_auto != None and var.addonmonitor.abortRequested() == False and func.check_addon_running() == True:
        #Check if it is time to auto login
        LastLoginSeconds = int((datetime.now() - var.ApiLastLogin).total_seconds())
        if LastLoginSeconds >= 890:
            if var.ApiLoggedIn == True:
                ApiLogin(False)
        else:
            xbmc.sleep(5000)

def ApiLogin(LoginNotification=False):
    #Check login retry limit
    if var.ApiLoginCount > 2:
        notificationIcon = path.resources('resources/skins/default/media/common/error.png')
        xbmcgui.Dialog().notification(var.addonname, 'Aanmeld poging limiet bereikt, herstart de add-on.', notificationIcon, 2500, False)
        return False
    else:
        var.ApiLoginCount += 1

    #Generate the device id
    ApiGenerateDeviceId()

    #Check the login type
    if var.addon.getSetting('LoginType') == 'Abonnementsnummer':
        #Check login settings
        if var.addon.getSetting('LoginUsername') == '' or var.addon.getSetting('LoginPassword') == '':
            var.addon.openSettings()
            return False

        loginDevice = classes.Class_ApiLogin_deviceRegistrationData()
        loginDevice.deviceId = var.addon.getSetting('LoginDeviceId120')
        loginDevice.vendor = "Webbie Player"
        loginDevice.model = str(var.addonversion)
        loginDevice.deviceFirmVersion = "Kodi"
        loginDevice.appVersion = str(var.kodiversion)
        loginDevice = loginDevice.__dict__

        loginAuth = classes.Class_ApiLogin_credentialsStdAuth()
        loginAuth.username = var.addon.getSetting('LoginUsername')
        loginAuth.password = var.addon.getSetting('LoginPassword')
        loginAuth.deviceRegistrationData = loginDevice
        loginAuth = loginAuth.__dict__

        loginData = classes.Class_ApiLogin_stdAuth()
        loginData.credentialsStdAuth = loginAuth
        loginData = loginData.__dict__
    else:
        #Check login settings
        if var.addon.getSetting('LoginEmail') == '' or var.addon.getSetting('LoginPasswordEmail') == '':
            var.addon.openSettings()
            return False

        loginDevice = classes.Class_ApiLogin_deviceInfo()
        loginDevice.deviceId = var.addon.getSetting('LoginDeviceId120')
        loginDevice.deviceVendor = "Webbie Player"
        loginDevice.deviceModel = str(var.addonversion)
        loginDevice.deviceFirmVersion = "Kodi"
        loginDevice.appVersion = str(var.kodiversion)
        loginDevice = loginDevice.__dict__

        loginCredentials = classes.Class_ApiLogin_credentials()
        loginCredentials.username = var.addon.getSetting('LoginEmail')
        loginCredentials.password = var.addon.getSetting('LoginPasswordEmail')
        loginCredentials = loginCredentials.__dict__

        loginAuth = classes.Class_ApiLogin_credentialsExtAuth()
        loginAuth.deviceInfo = loginDevice
        loginAuth.credentials = loginCredentials
        loginAuth = loginAuth.__dict__

        loginData = classes.Class_ApiLogin_extAuth()
        loginData.credentialsExtAuth = loginAuth
        loginData = loginData.__dict__

    #Request login by sending data
    try:
        DownloadHeaders = {
            "User-Agent": var.addon.getSetting('CustomUserAgent'),
            "Content-Type": "application/json"
        }

        DownloadData = json.dumps(loginData).encode('ascii')
        DownloadRequest = hybrid.urllib_request(path.api_login(), data=DownloadData, headers=DownloadHeaders)
        DownloadDataHttp = hybrid.urllib_urlopen(DownloadRequest)
        DownloadDataJson = json.load(DownloadDataHttp)
    except:
        notificationIcon = path.resources('resources/skins/default/media/common/error.png')
        xbmcgui.Dialog().notification(var.addonname, 'Aanmelden is mislukt.', notificationIcon, 2500, False)
        var.ApiLoggedIn = False
        var.ApiLastLogin = datetime(1970, 1, 1)
        var.ApiLoginCookie = ''
        var.ApiLoginToken = ''
        return False

    #Check if connection is successful
    if DownloadDataJson['resultCode'] and DownloadDataJson['errorDescription']:
        resultCode = DownloadDataJson['resultCode']
        resultMessage = DownloadDataJson['message']
        errorDescription = DownloadDataJson['errorDescription']
        if errorDescription == '403-3161':
            notificationIcon = path.resources('resources/skins/default/media/common/error.png')
            xbmcgui.Dialog().notification(var.addonname, 'Inloggen 24 uur geblokkeerd.', notificationIcon, 2500, False)
            var.ApiLoggedIn = False
            var.ApiLastLogin = datetime(1970, 1, 1)
            var.ApiLoginCookie = ''
            var.ApiLoginToken = ''
            return False
        elif errorDescription == '401-3035':
            notificationIcon = path.resources('resources/skins/default/media/common/error.png')
            xbmcgui.Dialog().notification(var.addonname, 'Uw account is (tijdelijk) geblokkeerd.', notificationIcon, 2500, False)
            var.ApiLoggedIn = False
            var.ApiLastLogin = datetime(1970, 1, 1)
            var.ApiLoginCookie = ''
            var.ApiLoginToken = ''
            return False
        elif resultCode == 'KO':
            notificationIcon = path.resources('resources/skins/default/media/common/error.png')
            xbmcgui.Dialog().notification(var.addonname, 'Onjuiste gegevens: ' + resultMessage, notificationIcon, 5000, False)
            var.ApiLoggedIn = False
            var.ApiLastLogin = datetime(1970, 1, 1)
            var.ApiLoginCookie = ''
            var.ApiLoginToken = ''
            return False

    #Read and set the returned token
    var.ApiLoginToken = hybrid.urllib_getheader(DownloadDataHttp, 'X-Xsrf-Token')

    #Filter and clone the cookie contents
    HeaderCookie = hybrid.urllib_getheader(DownloadDataHttp, 'Set-Cookie')
    
    var.ApiLoginCookie = ''
    cookie_split = re.findall(r"([^\s]*?=.*?(?=;|,|$))", HeaderCookie)
    for cookie in cookie_split:
        if cookie.startswith('Path') == False and cookie.startswith('Expires') == False and cookie.startswith('Max-Age') == False:
            var.ApiLoginCookie += cookie + ';'
    var.ApiLoginCookie = var.ApiLoginCookie[:-1]

    #Show the login notification
    if LoginNotification == True:
        xbmcgui.Dialog().notification(var.addonname, 'Aangemeld, veel kijkplezier.', var.addonicon, 2500, False)

    #Check if user has pvr access
    ApiCheckPvrAccess(DownloadDataJson)

    #Update api login variables
    var.ApiLoginCount = 0
    var.ApiLoggedIn = True
    var.ApiLastLogin = datetime.now()

    #Start the auto login thread
    if var.thread_login_auto == None:
        var.thread_login_auto = Thread(target=thread_login_auto)
        var.thread_login_auto.start()

    return True

def ApiCheckPvrAccess(DownloadDataJson):
    try:
        for package in DownloadDataJson['resultObj']['profile']['profileData']['packageList']:
            if package['packageType'] == 'NPVR':
                if package['packageIsLocked'] == 'Y':
                    var.RecordingAccess = False
                    return False
                else:
                    var.RecordingAccess = True
                    return True
    except:
        pass