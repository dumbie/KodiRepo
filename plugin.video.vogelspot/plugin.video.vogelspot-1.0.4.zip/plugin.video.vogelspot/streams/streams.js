[
  {
    "id": "bosuil",
    "name": "Bosuil Binnen",
    "location": "Meinweg, Limburg",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Bosuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Bosuil1"
  },
  {
    "id": "bosuil",
    "name": "Bosuil Buiten",
    "location": "Meinweg, Limburg",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Bosuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Bosuil2"
  },
  {
    "id": "kerkuil",
    "name": "Kerkuil Binnen",
    "location": "Grenslicht, Woold, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Kerkuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Kerkuil1"
  },
  {
    "id": "kerkuil",
    "name": "Kerkuil Buiten",
    "location": "Grenslicht, Woold, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Kerkuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Kerkuil2"
  },
  {
    "id": "misc",
    "name": "Vijver",
    "location": "Stuwwal, Veluwe",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Vijver1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Vijver1"
  },
  {
    "id": "merel",
    "name": "Merel",
    "location": "Een schuurtje",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Merel1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Merel1"
  },
  {
    "id": "koolmees",
    "name": "Koolmees Binnen",
    "location": "Dongen, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Koolmees1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Koolmees1"
  },
  {
    "id": "koolmees",
    "name": "Koolmees Buiten",
    "location": "Dongen, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Koolmees2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Koolmees2"
  },
  {
    "id": "zeearend",
    "name": "Zeearend",
    "location": "Alde Feanen, Friesland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Zeearend1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Zeearend1"
  },
  {
    "id": "visarend",
    "name": "Visarend",
    "location": "Biesbosch, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Visarend1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": ""
  },
  {
    "id": "ooievaar",
    "name": "Ooievaar",
    "location": "Gennep, Limburg",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ooievaar1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ooievaar1"
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Nest",
    "location": "De Mortel, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=SlechtvalkGemert3&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=SlechtvalkGemert3"
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Rooster",
    "location": "De Mortel, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=SlechtvalkGemert2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=SlechtvalkGemert2"
  },
  {
    "id": "oehoe",
    "name": "Oehoe Nest",
    "location": "Een kapschuur",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Oehoe1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Oehoe1"
  },
  {
    "id": "oehoe",
    "name": "Oehoe Schuur",
    "location": "Een kapschuur",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Oehoe2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Oehoe2"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Buiten",
    "location": "Winterswijk, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil3&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil3"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen achter",
    "location": "Winterswijk, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil1"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen voor",
    "location": "Winterswijk, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil2"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen",
    "location": "Sprundel, Noord-Brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Steenuil2Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "steenuil",
    "name": "Steenuil Buiten",
    "location": "Sprundel, Noord-Brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Steenuil2Buiten.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "holenduif",
    "name": "Holenduif / Bosuil Binnen",
    "location": "Heuvelrug, Utrecht",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Bosuil3Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "holenduif",
    "name": "Holenduif / Bosuil Buiten",
    "location": "Heuvelrug, Utrecht",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Bosuil3Buiten.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "turksetortel",
    "name": "Turkse Tortel",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/TurkseTortel.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "bosuil",
    "name": "Bosuil / Holenduif / Torenvalk",
    "location": "Rekken, Gelderland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Bosuil4Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "kerkuil",
    "name": "Kerkuil Binnen",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Kerkuil1Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "kerkuil",
    "name": "Kerkuil Buiten",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Kerkuil1Buiten.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "ransuil",
    "name": "Ransuil",
    "location": "Wassenaar, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Ransuil.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "spreeuw",
    "name": "Spreeuw / Eekhoorn",
    "location": "Sprundel, Noord-Brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Spreeuw4Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "spreeuw",
    "name": "Spreeuw",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Spreeuw2Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "koolmees",
    "name": "Koolmees",
    "location": "Blijde Wei, Rotterdam",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/BlijdeWei1.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "koolmees",
    "name": "Koolmees",
    "location": "Nieuw-lekkerland, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Koolmees2.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "pimpelmees",
    "name": "Pimpelmees",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Koolmees1Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "torenvalk",
    "name": "Torenvalk",
    "location": "Molenaarsgraaf, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Torenvalk2.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "torenvalk",
    "name": "Torenvalk",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Torenvalk3.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Buiten",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Slechtvalk1Buiten.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Binnen",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Slechtvalk1Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "buizerd",
    "name": "Buizerd",
    "location": "Hoeksche waard, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Buizerd.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "havik",
    "name": "Havik",
    "location": "Hoeksche waard, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Havik.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "lepelaar",
    "name": "Lepelaar",
    "location": "Nieuwkoop, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Lepelaar.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "misc",
    "name": "Voerbak",
    "location": "Sprundel, Noord-brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Voercam2Tafel.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "misc",
    "name": "Waterplas",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Plas.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "misc",
    "name": "Plasdras",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Dras.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "bosuil",
    "name": "Bosuil",
    "location": "Yew view garden, Engeland",
    "source": "Wildlifekate.co.uk",
    "stream": "https://stream.wildlifestreaming.io:8443/WildlifeKate/yew77.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "vos",
    "name": "Field Fox Cam",
    "location": "Lichfield garden, Engeland",
    "source": "Wildlifekate.co.uk",
    "stream": "https://stream.wildlifestreaming.io:8443/WildlifeKate/230.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "misc",
    "name": "Garden PTZ",
    "location": "Lichfield garden, Engeland",
    "source": "Wildlifekate.co.uk",
    "stream": "https://stream.wildlifestreaming.io:8443/WildlifeKate/235.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "misc",
    "name": "Feeding Platform",
    "location": "Lichfield garden, Engeland",
    "source": "Wildlifekate.co.uk",
    "stream": "https://stream.wildlifestreaming.io:8443/WildlifeKate/231.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "pinguin",
    "name": "Pinguin",
    "location": "Edinburgh, Schotland",
    "source": "Edinburgh Zoo",
    "stream": "https://595b9deb3d6ac.streamlock.net/qlive/edinburghzoo104225.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "koala",
    "name": "Koala",
    "location": "Edinburgh, Schotland",
    "source": "Edinburgh Zoo",
    "stream": "https://5cee0d703d908.streamlock.net/rtplive/edinburghzoo103750_koala.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "panda",
    "name": "Panda",
    "location": "Edinburgh, Schotland",
    "source": "Edinburgh Zoo",
    "stream": "https://5cee0d703d908.streamlock.net/rtplive/EDZ-PH2-ShowDen2.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "ijsvogel",
    "name": "[COLOR ffe80707]X[/COLOR] Ijsvogel Binnen",
    "location": "Helmond, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ijsvogel1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ijsvogel1"
  },
  {
    "id": "ijsvogel",
    "name": "[COLOR ffe80707]X[/COLOR] Ijsvogel Buiten",
    "location": "Helmond, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ijsvogel2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ijsvogel2"
  },
  {
    "id": "huiszwaluw",
    "name": "[COLOR ffe80707]X[/COLOR] Huiszwaluw",
    "location": "Noordwijkerhout, Zuid-Holland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=huiszwaluw2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=huiszwaluw2"
  }
]