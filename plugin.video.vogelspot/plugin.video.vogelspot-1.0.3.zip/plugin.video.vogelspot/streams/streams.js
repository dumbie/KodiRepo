[
  {
    "id": "bosuil",
    "name": "Bosuil Binnen",
    "location": "Meinweg, Limburg",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Bosuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Bosuil1"
  },
  {
    "id": "bosuil",
    "name": "Bosuil Buiten",
    "location": "Meinweg, Limburg",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Bosuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Bosuil2"
  },
  {
    "id": "kerkuil",
    "name": "Kerkuil Binnen",
    "location": "Grenslicht, Woold, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Kerkuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Kerkuil1"
  },
  {
    "id": "kerkuil",
    "name": "Kerkuil Buiten",
    "location": "Grenslicht, Woold, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Kerkuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Kerkuil2"
  },
  {
    "id": "misc",
    "name": "Vijver",
    "location": "Stuwwal, Veluwe",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Vijver1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Vijver1"
  },
  {
    "id": "merel",
    "name": "Merel Nest",
    "location": "Een schuurtje",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Merel1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Merel1"
  },
  {
    "id": "zeearend",
    "name": "Zeearend Nest",
    "location": "Alde Feanen, Friesland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Zeearend1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Zeearend1"
  },
  {
    "id": "visarend",
    "name": "Visarend Nest",
    "location": "Biesbosch, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Visarend1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": ""
  },
  {
    "id": "ooievaar",
    "name": "Ooievaar Nest",
    "location": "Gennep, Limburg",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ooievaar1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ooievaar1"
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Nest",
    "location": "De Mortel, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=SlechtvalkGemert3&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=SlechtvalkGemert3"
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Rooster",
    "location": "De Mortel, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=SlechtvalkGemert2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=SlechtvalkGemert2"
  },
  {
    "id": "oehoe",
    "name": "Oehoe Nest",
    "location": "Een kapschuur",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Oehoe1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Oehoe1"
  },
  {
    "id": "oehoe",
    "name": "Oehoe Schuur",
    "location": "Een kapschuur",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Oehoe2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Oehoe2"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Buiten",
    "location": "Winterswijk, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil3&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil3"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen voor",
    "location": "Winterswijk, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil1"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen achter",
    "location": "Winterswijk, Gelderland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil2"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen",
    "location": "Sprundel, Noord-Brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Steenuil2Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "steenuil",
    "name": "Steenuil Buiten",
    "location": "Sprundel, Noord-Brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Steenuil2Buiten.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "buizerd",
    "name": "Buizerd",
    "location": "Hoeksche waard, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Buizerd.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "spreeuw",
    "name": "Spreeuw / Eekhoorn",
    "location": "Sprundel, Noord-Brabant",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Spreeuw4Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "torenvalk",
    "name": "Torenvalk kast",
    "location": "Alphen aan den Rijn, Zuid-Holland",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Torenvalk3.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "pinguin",
    "name": "Pinguin",
    "location": "Edinburgh, Scotland",
    "source": "Edinburgh Zoo",
    "stream": "https://595b9deb3d6ac.streamlock.net/qlive/edinburghzoo104225.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "koala",
    "name": "Koala",
    "location": "Edinburgh, Scotland",
    "source": "Edinburgh Zoo",
    "stream": "https://5cee0d703d908.streamlock.net/rtplive/edinburghzoo103750_koala.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "panda",
    "name": "Panda",
    "location": "Edinburgh, Scotland",
    "source": "Edinburgh Zoo",
    "stream": "https://5cee0d703d908.streamlock.net/rtplive/EDZ-PH2-ShowDen2.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "ijsvogel",
    "name": "Ijsvogel Binnen",
    "location": "Helmond, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ijsvogel1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ijsvogel1"
  },
  {
    "id": "ijsvogel",
    "name": "Ijsvogel Buiten",
    "location": "Helmond, Noord-Brabant",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ijsvogel2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ijsvogel2"
  },
  {
    "id": "huiszwaluw",
    "name": "Huiszwaluw",
    "location": "Noordwijkerhout, Zuid-Holland",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=huiszwaluw2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=huiszwaluw2"
  }
]