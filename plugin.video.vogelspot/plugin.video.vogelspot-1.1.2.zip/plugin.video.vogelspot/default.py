import main

#Add-on launch
if __name__ == '__main__':
    main.switch_to_page()
