[
  {
    "id": "bosuil",
    "name": "Bosuil Binnen (Meinweg, Limburg)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Bosuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Bosuil1"
  },
  {
    "id": "bosuil",
    "name": "Bosuil Buiten (Meinweg, Limburg)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Bosuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Bosuil2"
  },
  {
    "id": "misc",
    "name": "Vijver (Stuwwal, Veluwe)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Vijver1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Vijver1"
  },
  {
    "id": "merel",
    "name": "Merel (Een schuurtje)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Merel1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Merel1"
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Nest (De Mortel, Noord-Brabant)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=SlechtvalkGemert3&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=SlechtvalkGemert3"
  },
  {
    "id": "slechtvalk",
    "name": "Slechtvalk Rooster (De Mortel, Noord-Brabant)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=SlechtvalkGemert2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=SlechtvalkGemert2"
  },
  {
    "id": "oehoe",
    "name": "Oehoe Nest (Een kapschuur)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Oehoe1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Oehoe1"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Buiten (Winterswijk, Gelderland)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil3&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil3"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnenvoor (Winterswijk, Gelderland)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil1"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnenachter (Winterswijk, Gelderland)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Steenuil2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Steenuil2"
  },
  {
    "id": "steenuil",
    "name": "Steenuil Binnen (Sprundel, Noord-Brabant)",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Steenuil2Binnen.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "steenuil",
    "name": "Steenuil Buiten (Sprundel, Noord-Brabant)",
    "source": "Nestkastlive",
    "stream": "https://5d881567b7568.streamlock.net/live/Steenuil2Buiten.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "pinguin",
    "name": "Pinguin",
    "source": "Edinburgh Zoo",
    "stream": "https://595b9deb3d6ac.streamlock.net/qlive/edinburghzoo104225.stream/playlist.m3u8",
    "token": ""
  },
  {
    "id": "ijsvogel",
    "name": "Ijsvogel Binnen (Helmond, Noord-Brabant)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ijsvogel1&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ijsvogel1"
  },
  {
    "id": "ijsvogel",
    "name": "Ijsvogel Buiten (Helmond, Noord-Brabant)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=Ijsvogel2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=Ijsvogel2"
  },
  {
    "id": "huiszwaluw",
    "name": "Huiszwaluw (Noordwijkerhout, Zuid-Holland)",
    "source": "Beleefdelente",
    "stream": "https://rrr.sz.xlcdn.com/?account=bdl&file=huiszwaluw2&type=live&service=wowza&protocol=https&output=playlist.m3u8",
    "token": "https://www.vogelbescherming.nl/cfc/bdl/CFJetStream/JetStream.cfc?method=GenerateToken&streamname=huiszwaluw2"
  }
]