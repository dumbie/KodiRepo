import os
import var

def resources(fileName):
    return os.path.join(var.addonpath, fileName)

def addonstorage(fileName):
    return os.path.join(var.addonstorage, fileName)

def streams():
    return 'https://raw.githubusercontent.com/dumbie/kodirepo/master/plugin.video.vogelspot/streams/streams.js'

def images(streamId):
    return 'https://raw.githubusercontent.com/dumbie/kodirepo/master/plugin.video.vogelspot/streams/' + streamId + '.png'
