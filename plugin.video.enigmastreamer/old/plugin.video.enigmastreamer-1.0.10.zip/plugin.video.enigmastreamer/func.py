import os
import var

#Update controls
def updateLabelText(_self, controlId, string):
    _self.getControl(controlId).setLabel(string)

#Check if string is empty
def string_isnullorempty(string):
    if string and string.strip():
        return False
    else:
        return True

#Search for ChannelNumber in container
def search_channelnumber_listcontainer(listcontainer, searchChannelNumber):
    listitemcount = listcontainer.size()
    for itemNum in range(0, listitemcount):
        ChannelId = listcontainer.getListItem(itemNum).getProperty('ChannelNumber')
        if ChannelId == searchChannelNumber: return itemNum
    return None

#Get add-on resource path
def path_resources(iconName):
    return os.path.join(var.addonpath, iconName)
